#!/bin/bash

DATA_PIPELINE=$1
sed -i '' "s/DATA_PIPELINE_PLACEHOLDER/$DATA_PIPELINE/g" terraform/env/*.hcl
sed -i '' "s/DATA_PIPELINE_PLACEHOLDER/$DATA_PIPELINE/g" terraform/variables.tf