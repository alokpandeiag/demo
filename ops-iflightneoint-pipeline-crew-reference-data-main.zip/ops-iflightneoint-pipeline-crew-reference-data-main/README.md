# ops-odie-datapipeline-template
<!---Replace <INSERT_REPO_HERE> with your repository -->
[![Terraform Deploy](https://github.com/BritishAirways-Ent/<INSERT_REPO_HERE>/actions/workflows/terraform-deploy.yaml/badge.svg)](https://github.com/BritishAirways-Ent/<INSERT_REPO_HERE>/actions/workflows/terraform-deploy.yaml)

<!--- You can copypaste the following directly from the 'information' area for the project in Sonarcloud -->
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=<INSERT_TOKEN_HERE>)](https://sonarcloud.io/summary/new_code?id=SONARCLOUD_PROJECT_HERE>)


<!---
Support for Snyk later
[![Known Vulnerabilities](https://snyk.io/test/github/{username}/{repo}/badge.svg)]
-->

This is a template that can be used for setting up a new data pipeline repository. This repository has a basic initial Terraform configuration which has remote state configured for dev, uat and prod. It also has a sample Lambda function which uses the remote state of the core infra repository to retrieve information about resources that are created in that repository. 

The below table of contents is automatically generated and updated upon saving by [this VSCode extension](https://marketplace.visualstudio.com/items?itemName=yzhang.markdown-all-in-one). I suggest you install it
- [ops-odie-datapipeline-template](#ops-odie-datapipeline-template)
  - [Setup repository after creation with template](#setup-repository-after-creation-with-template)
    - [Terraform](#terraform)
    - [Repository permissions](#repository-permissions)
    - [Repository deployment environments](#repository-deployment-environments)
  - [Setup local environment](#setup-local-environment)
    - [Overview](#overview)
      - [pre-commit hooks](#pre-commit-hooks)
      - [pre-push hooks](#pre-push-hooks)
      - [Github Action Pull-Request to main](#github-action-pull-request-to-main)
      - [Docstrings in Python](#docstrings-in-python)
    - [Installation Quickstart](#installation-quickstart)
    - [Useful commands](#useful-commands)
  - [Guidelines (for coding, formatting, naming conventions)](#guidelines-for-coding-formatting-naming-conventions)
    - [For Terraform](#for-terraform)
      - [ECP](#ecp)
      - [Cyber Requirements](#cyber-requirements)
    - [For Python](#for-python)
  - [Contribution](#contribution)
    - [Prerequisites](#prerequisites)
    - [Contributing](#contributing)
      - [Naming conventions / Semantic release](#naming-conventions--semantic-release)
      - [Process](#process)
  - [Deployment of new services](#deployment-of-new-services)
      - [A. For your Python Code](#a-for-your-python-code)
      - [B. For your Terraform Code](#b-for-your-terraform-code)
        - [Prerequisites](#prerequisites-1)
        - [Terraform code](#terraform-code)
  - [Testing](#testing)
    - [Sonarcloud](#sonarcloud)
  - [Release](#release)
  - [Useful links (link to Jira board, confluence, best practices, code owners)](#useful-links-link-to-jira-board-confluence-best-practices-code-owners)
  - [Acknowledgements](#acknowledgements)
  - [FAQs](#faqs)
    - [1. How to install new Python packages in Pipenv:](#1-how-to-install-new-python-packages-in-pipenv)
      - [Installing \[packages\]](#installing-packages)
      - [Installing \[dev-packages\]](#installing-dev-packages)
      - [What's next?](#whats-next)
- [Terraform-docs](#terraform-docs)
  - [Requirements](#requirements)
  - [Providers](#providers)
  - [Modules](#modules)
  - [Resources](#resources)
  - [Inputs](#inputs)
  - [Outputs](#outputs)


## Setup repository after creation with template

### Terraform

**It is imperative that you do not reuse the name of another pipeline by accident**
Please check that there are no other repositories with similar names, and check the contents of the S3 bucket within your dev environment containing the terraform state that it does not contain a statefile with your application name.


The `repo_setup.sh` script can be used for configuring Terraform. The name of the data pipeline must be passed to it. An example is below for configuring a repository where the datapipeline is `aidx`. 

```
bash repo_setup.sh aidx
```

### Repository permissions
Repositories can't inherit a lot of configuration from their template repository. Branch protections being one of them, ensure that appropriate branch protections are configured against the main branch. Including deletion protection.

### Repository deployment environments

You will need to ensure you have configured github 'environments' within your repository for:
- dev
- uat
- qa
- prd

Along with the appropriate deployement protections in place for each one, i.e not allowing people who requested the deployment to approve their own. Requiring at least 1-2 approvals per environment etc.

## Setup local environment

### Overview
This template consists of both pre-commit and pre-push hooks and there is a check running when there is a pull request to merge your branch with main.

This template also can be used for setting up your python project with the necessary checks/tests for code quality standards. The pipenv currently runs in Python 3.10.

#### pre-commit hooks
The pre-commit hooks run only when you try to commit staged files and it runs only in the staged files. The pre-commit hooks currently consist of the below checks/runs:
- check-yaml - checks yaml files for parseable syntax
- end-of-file-fixer - ensures that a file is either empty, or ends with one newline
- trailing-whitespace - trims trailing whitespace
- isort - isort is a Python utility / library to sort imports alphabetically, and automatically separated into sections and by type
- black - Python code formatter
- pylint - Pylint analyses your code without actually running it, checks for coding standards etc.
- terraform_fmt - automatically formats terraform code to community standards
- terraform_tflint - lints the terraform hcl for syntax errors
- terraform-docs - automatically updates [the terraform docs section of README.md](#terraform-docs)with the description of terraform variables, wether they are mandatory or not, and any dependencies it requires
- commitzen check - Ensures the commit message follows the semantic title checks

#### pre-push hooks
The pre-push hooks run only in the committed files when you try to push the changes in the branch. Main branch is excluded because it will be a protected branch that we should not push directly. The pre-commit hooks currently consist of the below checks/runs:
- pytest - testing library for Python
- mypy  - is a static type checker for Python

#### Github Action Pull-Request to main
This Github Action is triggered when you create a new pull request to main and it does the following work:
1. Downloads and installs pipenv
2. Runs pylint for all the python files
3. Runs all the tests to make sure that we have above 80% coverage

#### Docstrings in Python
We will be using the following [guide](https://github.com/google/styleguide/blob/gh-pages/pyguide.md#s3.8-comments-and-docstrings) for creating docstring in Python.

### Installation Quickstart

**Note** - You will need to have pyenv set up as long as your shell environment, an [example of how to do this with python here](https://medium.com/@ThisIsUpen/python-setup-on-macos-59b2329bd920)

You can quickly install the needed dependencies/libraries by running the initial setup script like below:
```bash
chmod +x local_setup.sh
./local_setup.sh
```
Alternatively, you can run manually the commands below:
1. Install pipenv
```bash
pip install --user pipenv
```
2. Set up version for pipenv
```bash
pipenv --python 3.10
```
3. Install all dependencies for pipenv
```bash
pipenv install --dev
```
4. Install pre-commit hooks
```bash
pipenv run  pre-commit install --hook-type pre-commit --hook-type pre-push
```

### Useful commands
1. Activate your Python environment
```bash
pipenv shell
```
2. Run commands within your Python environment without activating the Python environment. Please do not use brackets.
```bash
pipenv run {your command}
```
One example of running pylint for src folder
```bash
pipenv run pylint src
```

## Guidelines (for coding, formatting, naming conventions) 

### For Terraform

All resources in AWS must be named according to the [AWS Naming Scheme](https://iagtech.atlassian.net/wiki/spaces/ICU/pages/381190376/AWS+Resource+Naming+Standards) and where possible following the best practices for terraform. Including: 
- Modulising where possible
- Making any changes with the idea any changes you make will affect multiple resources using your module
- Maintainability and readability in mind over obfuscation or needless complexity
- `terraform fmt` should be run before committing/pushing, this can be handled in pre-commit config if necessary

Security sanity checks will be performed by tfsec upon your pull request, ultimately however it is your responsibility to validate any changes you and others are making. Keep an eye out for exceptions made within tfsec if they are relevant or excluding a configuration issue incorrectly

There is a push across the business to implement [Synk](https://snyk.io/), this would replace tfsec if implemented within D&I/IOPS

#### ECP

There are also standards enforced due to the move to Enterprise Cloud Platform (ECP), resource tagging being one of them

There's multiple resources within service now:
- [What is ECP (The Enterprise Cloud Platform)?](https://iagprod.service-now.com/iag_gbs?id=kb_article_view&sysparm_article=KB0011979&sys_kb_id=f1452a8383694a90d8ab9880deaad368&spa=1)
- [ECP Tagging and Compliance Service | Overview, How-to Guide and Operating Model](https://iagprod.service-now.com/kb_view.do?sysparm_article=KB0011971)
- [Enterprise Cloud Platform (ECP) - Frequently Asked Questions (FAQs)](https://iagprod.service-now.com/iag_gbs?id=kb_article&sys_id=52250581c3acc6d0585cf9270501315e&spa=1)

Some of these may cause issues in your AWS account if you do not comply, a prime example is configuring EC2 instance with a public IP address (even if it's whitelisted) will cause it to be shut down upon discovery. This is an automatic AWS Config Policy

#### Cyber Requirements

All major changes ultimately should be discussed and signed off with Cyber, examples where this should happen:
- Using new software not used by anyone else at BA
- New external connectivity to clients
- New services being released into prod (PAs should already know of this)

### For Python

IOPS follow [these](https://iagtech.atlassian.net/wiki/spaces/IO/pages/1059129132/Python+-+Software+Engineering+Guidelines) coding standards, which are implemented within the precommit configuration

More topics surrounding this are covered further down the readme, i.e code coverage and testing etc.

## Contribution

### Prerequisites 
Please review the [Pull Request / Code Review Etiquette](https://iagtech.atlassian.net/wiki/spaces/IO/pages/1146924159/Code+Review+Etiquette+v0.1)

### Contributing

#### Naming conventions / Semantic release

Within the action `semantic-pull-request.yaml` you will see valid PR titles, you must follow these to get your PR merged in

Doing this also allows JIRA to keep track of github work related to your ticket

Valid titles are:
- fix
- feat
- docs
- style
- refactor
- perf
- test
- build
- ci
- chore

An example would be the PR that created this readme: `docs(IIDIP-3011): define-common-readme-format`

#### Process

**Note** - There is currently a push to use commitzen to handle commit messages & pre-commit, the below is written with this in mind.

These are the steps for contributing to the repository:
1. Make sure you are in the main branch and pull all new changes
2. Create a new branch from main using the following naming convention `IIDIP-[Ticket_Number]-[short description of the change]` for work on tickets or `hotfix-[short description of the change]` for fixes that don't exist in tickets
3. The next step is to make your changes and stage them in git. After that, you can commit them using the command `cz commit` which helps to generate a standardised commit message. If the changes fail the pre-commit/pre-push changes, then you could use `cz commit --retry` to use the commit message. __Note__: Ideally, the commit messages should be very specific and explain exactly what is changed.
4. After you have committed your changes, the next step is to push them using `git push` and the pre-push tests will run to make sure it passes all the tests.
5. When you are done with all of your changes, you will need to create a Pull-Request and you will need another Engineer to review your PR in order to deploy it in Dev
6. After deploying your changes in dev environment and manual testing in the Console, the next step is to merge the code with main and deploy the code in UAT. Please make sure you move the ticket to Ready for QA, so the QA team can start testing in UAT environment. 

## Deployment of new services

In order to deploy a new AWS Lambda for the first time, you will need to follow the below process:

#### A. For your Python Code

1. Create a new folder in the path `src/lambda_functions/{project_name}`, an example project name is 'cc_details_raw_to_processed'. **Important note:** Please **use snakecase** (underscores) in the name, otherwise, you will not be able to run pytest.
2. Add an empty file `__init__.py` in the above folder in order the folder to be considered as package by Python
3. Add a file `main.py` which **MUST** contain a function named `def lambda_handler(event, context):` and it **must** have a return statement. The return statemenet could be `return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        }`
4. Add all your necessary functionality for your AWS Lambda
5. Create a new folder in the path `tests/lambda_functions/{project_name}` for the unit tests of the functionality of your code. **Important note:** Please use exactly the same name as you used for first step and add `__init__.py` in the folder as well.
6. Add unit tests for any functionality in the Lambda. We have the following best practises for unit tests:
a. When you want to test a file, you will need to create a test file with the following naming convention `test_[filename].py`. For example if you want to test `main.py`, the test filename needs to be `test_main.py`
b. The same applies for the test functions as well. For example, if you want to test a function `def input_username(username):`, then you will need to create a test function using `def test_input_username_[short_reason_what_you_test](testusername):` where short_reason_what_you_test could be "input_exception","null_values" or even empty if you are testing the happy path of the function.


#### B. For your Terraform Code

##### Prerequisites
These are the steps that need to be done before you deploy your new Lambda:
1. If your AWS Lambda requires to integrate with MSK, you will need to create the MSK secrets/topics in the relevant repositories. Please contact other Engineers, if you are unsure about this step as it is important for the Plan to pass.

##### Terraform code
1. Create module in Terraform in the path `terraform/lambda/{project name}` with the same name as project name but **use kebabcase** (hyphens) instead of snakecase (underscores) and add all your terraform specific to your project.
2. Define your module in `terraform/lambda.tf` that will link with the above module. **Important note:** Please make sure the `function_name` variable is the same as the one you used to create the MSK secret (if needed) and needs to use only hyphens. Also, the function name **must** align with the src folder for the lambda function but will use hyphens instead of underscores. Please follow the examples of the other Lambdas.

After you are done with the above, you can create your first Pull-Request in order to merge the Lambda so the Lambda can be deployed in the Console and dev environment

## Testing

Unit tests are the responsibility of the developer, and must provide at least 80% coverage on all new code

Tests are run as part of the precommit configuration in this repository

### Sonarcloud
Sonarcloud is being rolled out across the business, there is a step provided in the main-pr.yml workflow in this repo which you may need to disable if you currently do not have access to sonarcloud for your team

## Release
[The release and deploy strategy is documented in confluence, please treat this as the source of truth](https://iagtech.atlassian.net/wiki/spaces/IO/pages/1223525272/Release+Deployment+Strategy+-+Acting)

## Useful links (link to Jira board, confluence, best practices, code owners)

These steps are written using the information from confluence: [Python - Software Engineering Guidelines](https://iagtech.atlassian.net/wiki/spaces/IO/pages/1059129132/Python+-+Software+Engineering+Guidelines)

If these standards change, please update the template to reflect them

[Engineering User Story Workflow Process](https://iagtech.atlassian.net/wiki/spaces/IO/pages/1214912340/Engineering+User+Story+Workflow+Process)

## Acknowledgements
Many thanks to @georgegkekas-iag who provided a baseline for this readme within the disp repository

As well as @sam-withey-iaggbs for providing deployment/QA information

## FAQs
### 1. How to install new Python packages in Pipenv:
There are two categories that we separate pipenv packages, these are:
1. `[dev-packages]`: These are all the packages that we need for development but are not dependencies for the AWS Lambdas to function.
2. `[packages]`: These are all the packages that are required for the AWS Lambdas to be able to run the functionality.

#### Installing [packages]
You can install new packages in pipenv by using the below command

```bash
pipenv install package_name==version
```
Where package_name is your package that you want to install and the version is the specific version number of the package.

#### Installing [dev-packages]
You can install new dev packages in pipenv by using the below command

```bash
pipenv install package_name==version --dev
```
Where package_name is your package that you want to install and the version is the specific version number of the package.

#### What's next?
When you install new packages in the pipenv and merge with main, please make sure you communicate this to all developers so they can update their pipenv.

# Terraform-docs
This section automatically updates via PR or by running the `terraform-docs markdown table --output-file README.md --output-mode inject .` command. Terraform repositories should have this automatically running via pre-commit hooks or as part of the PR pipeline. It relies on the below comment in the raw markdown existing, do not remove it
<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

No modules.

## Resources

No resources.

## Inputs

No inputs.

## Outputs

No outputs.
<!-- END_TF_DOCS -->