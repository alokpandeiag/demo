import os
import json
import boto3

# Initialize S3 client
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    # request_id = context.aws_request_id
    # _logger.update_request_id(request_id)
    
    try:
        print("DLQ Lambda function is invoked.")
        print(f"Received event: {event}")

        error_bucket = os.environ.get('BUCKET_NAME')

        # Check if there are records in the event
        if "Records" in event and len(event["Records"]) > 0:
            for record in event["Records"]:
                message_body = record['body']
                print(f"Processing Message ID: {record['messageId']}")
                print(f"Message Body: {message_body}")

                try:
                    object_key = f"failed-messages/{record['messageId']}.xml"

                    # Upload the message body to the S3 bucket
                    response = s3_client.put_object(
                        Bucket=error_bucket,
                        Key=object_key,
                        Body=message_body,
                        ContentType='application/xml'
                    )
                    print(f"Message saved to S3: {object_key}. The S3 Response: {response}")
                
                except Exception as s3_error:
                    print(f"Error saving message to S3: {str(s3_error)}")
                    continue  # You may choose to handle this differently

        return {
            'statusCode': 200,
            'body': 'DLQ Lambda executed successfully'
        }

    except Exception as e:
        # Log error details
        print(f"An error occurred in DLQ Lambda: {str(e)}")
        return {
            'statusCode': 500,
            'body': f"An error occurred in DLQ Lambda: {str(e)}"
        }