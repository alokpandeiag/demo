
from src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.entity.aircraft_subtype_FleetMapping import FlightCrewAircraftFleetMapping
from src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.XMLtojsonobject import json_object_from_xml
from src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.aircraft_subtypes_dao_int import create_aircraft_subtype,delete_aircraft_subtype,update_aircraft_subtype
from src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util import LoggerFactory as _logger
from src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.FileLoadUtility import load_err_file

_logger.update_class_name(__name__)

configs = load_err_file()
VALIDATION_EXCEPTIONS = configs['VALIDATION EXCEPTIONS']
BUSINESS_EXCEPTIONS = configs['BUSINESS EXCEPTIONS']

def parse_xml_message(xml_file, request_id):
    _logger.update_request_id(request_id)
    try: 
        dict1 = json_object_from_xml(xml_file, request_id)
        # Check if the conversion was successful
        if dict1 is None:
            _logger.update_error_code('cr_ref_acst_rtu_500-0031')
            _logger.log_error(configs['TECHNICAL EXCEPTIONS']['cr_ref_acst_rtu_500-0031'])
            return None  # Return None or handle as appropriate

        _logger.log_debug("XML message converted to JSON OBJECTS successfully.")
        return dict1

    except Exception as e:
        _logger.update_error_code('cr_ref_acst_rtu_500-0030')
        _logger.log_error(configs['TECHNICAL EXCEPTIONS']['cr_ref_acst_rtu_500-0030'])
        _logger.log_error(f"The Exception is : {e}")
        return "Failure"


def initialize_aircraft_subtype_object_int(json_object, request_id):
    _logger.update_request_id(request_id)
    try:  
        AIRCRAFT_OWNER = json_object['aircraftSubtype']['aircraftSubtypeIdentifier']['aircraftOwner'] 
        AIRCRAFT_SUBTYPE = json_object['aircraftSubtype']['aircraftSubtypeIdentifier']['aircraftSubtype'] 
        AIRCRAFT_TYPE_IATA = json_object['aircraftSubtype']['typeInformation']['aircraftTypeIata']
        AIRCRAFT_TYPE_ICAO = json_object['aircraftSubtype']['typeInformation']['aircraftTypeIcao']
        AIRCRAFT_SUBTYPE_ICAO = json_object['aircraftSubtype']['typeInformation']['aircraftSubtypeICAO']
        FLEET_CODE_FICO_CONSOLIDATED = json_object['aircraftSubtype']['typeInformation']['aircraftSubtypeLocal']
        EFFECTIVE_FROM_DATE = json_object['aircraftSubtype']['aircraftSubtypeIdentifier']['validFromDateTime']
        EFFECTIVE_TO_DATE = json_object['aircraftSubtype']['aircraftSubtypeIdentifier']['validToDateTime']
        aircraft_subtype_object_int = FlightCrewAircraftFleetMapping(AIRCRAFT_OWNER=AIRCRAFT_OWNER,
            AIRCRAFT_SUBTYPE=AIRCRAFT_SUBTYPE,
            AIRCRAFT_TYPE_IATA=AIRCRAFT_TYPE_IATA,
            AIRCRAFT_TYPE_ICAO=AIRCRAFT_TYPE_ICAO,
            AIRCRAFT_SUBTYPE_ICAO=AIRCRAFT_SUBTYPE_ICAO,
            FLEET_CODE_FICO_CONSOLIDATED=FLEET_CODE_FICO_CONSOLIDATED,
            EFFECTIVE_FROM_DATETIME=EFFECTIVE_FROM_DATE,
            EFFECTIVE_TO_DATETIME=EFFECTIVE_TO_DATE)
        _logger.log_info(f"Initialized Create AircraftSubtype object : {aircraft_subtype_object_int}")
        return aircraft_subtype_object_int
    except KeyError as e:
        missing_key = str(e)
        _logger.update_error_code('cr_ref_acst_rtu_300-0037')
        _logger.log_error(VALIDATION_EXCEPTIONS['cr_ref_acst_rtu_300-0037']) 
        _logger.log_error(f"The Element Missing is : {missing_key}")
        return None
    except Exception as e:
        _logger.update_error_code('cr_ref_acst_rtu_400-0083')
        _logger.log_error(BUSINESS_EXCEPTIONS['cr_ref_acst_rtu_400-0083']) 
        _logger.log_error(f"The Exception is : {e}")
        return None

def initialize_original_aircraft_subtype_object_int(json_object, request_id):
    _logger.update_request_id(request_id)
    try:
        AIRCRAFT_OWNER = json_object['aircraftSubtype']['aircraftSubtypeIdentifier']['originalSubtypeIdentifier']['originalAircraftOwner']
        AIRCRAFT_SUBTYPE = json_object['aircraftSubtype']['aircraftSubtypeIdentifier']['originalSubtypeIdentifier']['originalAircraftSubtype']
        AIRCRAFT_TYPE_IATA = json_object['aircraftSubtype']['typeInformation']['aircraftTypeIata']
        AIRCRAFT_TYPE_ICAO = json_object['aircraftSubtype']['typeInformation']['aircraftTypeIcao']
        AIRCRAFT_SUBTYPE_ICAO = json_object['aircraftSubtype']['typeInformation']['aircraftSubtypeICAO']
        FLEET_CODE_FICO_CONSOLIDATED = json_object['aircraftSubtype']['typeInformation']['aircraftSubtypeLocal']
        EFFECTIVE_FROM_DATE = json_object['aircraftSubtype']['aircraftSubtypeIdentifier']['originalSubtypeIdentifier']['originalValidFromDateTime']
        EFFECTIVE_TO_DATE = json_object['aircraftSubtype']['aircraftSubtypeIdentifier']['originalSubtypeIdentifier']['originalValidFromDateTime']
        
        original_aircraft_subtype_object_int = FlightCrewAircraftFleetMapping(AIRCRAFT_OWNER=AIRCRAFT_OWNER,
            AIRCRAFT_SUBTYPE=AIRCRAFT_SUBTYPE,
            AIRCRAFT_TYPE_IATA=AIRCRAFT_TYPE_IATA,
            AIRCRAFT_TYPE_ICAO=AIRCRAFT_TYPE_ICAO,
            AIRCRAFT_SUBTYPE_ICAO=AIRCRAFT_SUBTYPE_ICAO,
            FLEET_CODE_FICO_CONSOLIDATED=FLEET_CODE_FICO_CONSOLIDATED,
            EFFECTIVE_FROM_DATETIME=EFFECTIVE_FROM_DATE,
            EFFECTIVE_TO_DATETIME=EFFECTIVE_TO_DATE)
        _logger.log_info(f"Initialized Update AircraftSubtype object: {original_aircraft_subtype_object_int}")
        return original_aircraft_subtype_object_int
    except KeyError as e:
        missing_key = str(e)
        _logger.update_error_code('cr_ref_acst_rtu_300-0037')
        _logger.log_error(VALIDATION_EXCEPTIONS['cr_ref_acst_rtu_300-0037']) 
        _logger.log_error(f"The Element Missing is : {missing_key}")
        return None
    except Exception as e:
        _logger.update_error_code('cr_ref_acst_rtu_400-0084')
        _logger.log_error(BUSINESS_EXCEPTIONS['cr_ref_acst_rtu_400-0084']) 
        _logger.log_error(f"The Exception is : {e}")
        return None


def delete_aircraft_subtype_object_int(json_object, request_id):
    _logger.update_request_id(request_id)
    try:  
        AIRCRAFT_OWNER = json_object['aircraftSubtype']['aircraftSubtypeIdentifier']['aircraftOwner'] 
        AIRCRAFT_SUBTYPE = json_object['aircraftSubtype']['aircraftSubtypeIdentifier']['aircraftSubtype']
        EFFECTIVE_FROM_DATE = json_object['aircraftSubtype']['aircraftSubtypeIdentifier']['validFromDateTime']
        EFFECTIVE_TO_DATE = json_object['aircraftSubtype']['aircraftSubtypeIdentifier']['validToDateTime']
        delete_aircraft_subtype_object_int = FlightCrewAircraftFleetMapping(AIRCRAFT_OWNER=AIRCRAFT_OWNER,
            AIRCRAFT_SUBTYPE=AIRCRAFT_SUBTYPE,
            EFFECTIVE_FROM_DATETIME=EFFECTIVE_FROM_DATE,
            EFFECTIVE_TO_DATETIME=EFFECTIVE_TO_DATE)
        _logger.log_info(f"Initialized Delete AircraftSubtype object: {delete_aircraft_subtype_object_int}")
        return delete_aircraft_subtype_object_int
    except KeyError as e:
        missing_key = str(e)
        _logger.update_error_code('cr_ref_acst_rtu_300-0037')
        _logger.log_error(VALIDATION_EXCEPTIONS['cr_ref_acst_rtu_300-0037']) 
        _logger.log_error(f"The Element Missing is : {missing_key}")
        return None
    except Exception as e:
        _logger.update_error_code('cr_ref_acst_rtu_400-0085')
        _logger.log_error(BUSINESS_EXCEPTIONS['cr_ref_acst_rtu_400-0085']) 
        _logger.log_error(f"The Exception is : {e}")
        return None



def action_type_create(aircraft_subtype_object_int, request_id):
    _logger.update_request_id(request_id)
    try:
        result = create_aircraft_subtype(aircraft_subtype_object_int, request_id)
        return "Success" if result else "Failure"
    except Exception as e:
        _logger.update_error_code('cr_ref_acst_rtu_400-0086')
        _logger.log_error(BUSINESS_EXCEPTIONS['cr_ref_acst_rtu_400-0086'])
        _logger.log_error(f"The Exception is : {e}")
        return "Failure"


def action_type_update(aircraft_subtype_object_int, original_aircraft_subtype_object_int, request_id):
    _logger.update_request_id(request_id)
    try:
        result = update_aircraft_subtype(aircraft_subtype_object_int, original_aircraft_subtype_object_int, request_id)
        return "Success" if result else "Failure"
    except Exception as e:
        _logger.update_error_code('cr_ref_acst_rtu_400-0087')
        _logger.log_error(BUSINESS_EXCEPTIONS['cr_ref_acst_rtu_400-0087']) 
        _logger.log_error(f"The Exception is : {e}")
        return "Failure"

def action_type_delete(delete_aircraft_subtype_object_int, request_id):
    _logger.update_request_id(request_id)
    try:
        result = delete_aircraft_subtype(delete_aircraft_subtype_object_int, request_id)
        return "Success" if result else "Failure"
    except Exception as e:
        _logger.update_error_code('cr_ref_acst_rtu_400-0088')
        _logger.log_error(BUSINESS_EXCEPTIONS['cr_ref_acst_rtu_400-0088']) 
        _logger.log_error(f"The Exception is : {e}")
        return "Failure"
    


 
