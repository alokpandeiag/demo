"""Sample file."""


def hello():
    """Sample function."""
    return "Hello"
