
import os
import pytest
from unittest.mock import patch, MagicMock, Mock
from datetime import datetime
from zoneinfo import ZoneInfo
from src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.aircraft_subtypes_dao_int import create_aircraft_subtype, delete_aircraft_subtype, get_existing_record, update_aircraft_subtype, update_existing_record, handle_existing_records, handle_no_existing_records, ensure_datetime
from src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.entity.aircraft_subtype_FleetMapping import FlightCrewAircraftFleetMapping


@pytest.fixture
def mock_lambda_context():
    mock_context = Mock()
    mock_context.aws_request_id = 'mock_request_id'
    return mock_context


@pytest.fixture
def mock_object():    
    return FlightCrewAircraftFleetMapping(
        AIRCRAFT_OWNER='AB',
        AIRCRAFT_SUBTYPE='320',
        AIRCRAFT_TYPE_IATA='330',
        AIRCRAFT_TYPE_ICAO='A330',
        AIRCRAFT_SUBTYPE_ICAO='XYZ',
        FLEET_CODE_FICO_CONSOLIDATED='A330',
        EFFECTIVE_FROM_DATETIME=datetime.strptime('2024-01-01T00:00:00Z', '%Y-%m-%dT%H:%M:%SZ'),
        EFFECTIVE_TO_DATETIME=datetime.strptime('2025-01-01T00:00:00Z', '%Y-%m-%dT%H:%M:%SZ')
    )

@pytest.fixture
def mock_session():
    # Create a mock session
    session = MagicMock()
    
    # Create a mock query object
    mock_query = MagicMock()
    
    # Set up the return value for the .filter() and .first() calls
    mock_query.filter.return_value = mock_query
    mock_query.first.return_value = None  # or any predefined object
    
    # Assign the mock query object to the session.query()
    session.query.return_value = mock_query
    
    return session

# Record is found i.e. is_record_present returns True
@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.db_manager.Database.get_session')
@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.aircraft_subtypes_dao_int.is_record_present')   # ##Using patch as a Decorator:
def test_create_aircraft_subtype(mock_method, mock_get_session, mock_session, mock_object, mock_lambda_context):
    # Arrange
    mock_method.return_value = True       
    mock_get_session.return_value = mock_session

    # # Configure the mock to return a specific value when .first() is called       
    expected_result_list = [mock_object, mock_object]
    #mock_session.query().filter().first.return_value = None ''' Not required as we are mocking is_record_present() method
    mock_session.query().filter().all.return_value = expected_result_list

    request_id = mock_lambda_context.aws_request_id
    result = create_aircraft_subtype(mock_object, request_id)

    # Assert
    assert result == mock_object
    # mock_session.add.assert_called_once_with(aircraft_subtype_object)
    # mock_session.commit.assert_called_once()


# Test for when an exception occurs
@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.db_manager.Database.get_session')
def test_create_aircraft_subtype_exception(mock_get_session, mock_lambda_context):
    # Arrange
    mock_session = MagicMock()
    mock_get_session.return_value = mock_session
    request_id = mock_lambda_context.aws_request_id

    # Create a mock aircraft subtype object
    aircraft_subtype_object = MagicMock()
    
    # Simulate an exception when trying to commit
    mock_session.commit.side_effect = Exception("Database commit error")

    # Act
    result = create_aircraft_subtype(aircraft_subtype_object, request_id)

    # Assert
    assert result is None  # Ensure that the function returns None in case of an exception
    mock_session.rollback.assert_called_once()  # Ensure that rollback was called
    mock_session.close.assert_called_once()  # Ensure that session is closed



@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.db_manager.Database.get_session')
@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.aircraft_subtypes_dao_int.get_existing_record')
def test_delete_aircraft_subtype_success(mock_get_existing_record, mock_get_session, mock_session, mock_object, mock_lambda_context):
    """Test successful deletion of an aircraft subtype."""
    request_id = mock_lambda_context.aws_request_id

    # Mock the return value of get_existing_record to be a list
    mock_get_existing_record.return_value = [mock_object]  # Return a list with mock_object
    '''this mock_get_existing_record is mocked using the patch @patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.src.dao.aircraft_subtypes_dao_int.get_existing_record')
    so, basically this will not call the function instead it will mock it and we know this GET_EXISTING_RECORD function
     will return a list , thats why declared like that. '''

    mock_get_session.return_value = mock_session

    expected_result_list = [mock_object, mock_object]
    mock_session.query().filter().all.return_value = expected_result_list

    delete_aircraft_subtype_object_int = MagicMock()
    delete_aircraft_subtype_object_int.EFFECTIVE_TO_DATETIME = datetime(2023, 12, 31)

    result = delete_aircraft_subtype(delete_aircraft_subtype_object_int, request_id)

    assert result == delete_aircraft_subtype_object_int

# Test for when an exception occurs
@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.db_manager.Database.get_session')
def test_delete_aircraft_subtype_exception(mock_get_session, mock_lambda_context):
    # Arrange
    mock_session = MagicMock()
    mock_get_session.return_value = mock_session
    request_id = mock_lambda_context.aws_request_id

    # Create a mock aircraft subtype object
    aircraft_subtype_object = MagicMock()
    
    # Simulate an exception when trying to commit
    mock_session.commit.side_effect = Exception("Database commit error")

    # Act
    result = delete_aircraft_subtype(aircraft_subtype_object, request_id)

    # Assert
    assert result is None  # Ensure that the function returns None in case of an exception
    mock_session.rollback.assert_called_once()  # Ensure that rollback was called
    mock_session.close.assert_called_once()  # Ensure that session is closed


@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.db_manager.Database.get_session')
@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.aircraft_subtypes_dao_int.get_existing_record')
@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.aircraft_subtypes_dao_int.handle_existing_records')
def test_update_aircraft_subtype_success(mock_handle_existing_records, mock_get_existing_record, mock_get_session, mock_session, mock_object, mock_lambda_context):
    """Test successful deletion of an aircraft subtype."""
    request_id = mock_lambda_context.aws_request_id

    mock_get_existing_record.return_value = [MagicMock()]  # Simulate existing records found  # Return a list with mock_object
    aircraft_subtype_object_int = MagicMock()
    original_aircraft_subtype_object_int = MagicMock()
    mock_get_session.return_value = mock_session

   # Call the function
    result = update_aircraft_subtype(aircraft_subtype_object_int, original_aircraft_subtype_object_int, request_id)

    # Assertions
    assert result == aircraft_subtype_object_int
    mock_handle_existing_records.assert_called_once_with(mock_session, aircraft_subtype_object_int, mock_get_existing_record.return_value, request_id)

    # assert result ==  original_aircraft_subtype_object_int
    # mock_handle_no_existing_records.assert_called_once_with(mock_session, aircraft_subtype_object_int, original_aircraft_subtype_object_int, mock_get_existing_record.return_value, request_id)
    mock_session.commit.assert_called_once()

@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.db_manager.Database.get_session')
def test_update_aircraft_subtype_exception(mock_get_session, mock_lambda_context):
    # Arrange
    mock_session = MagicMock()
    mock_get_session.return_value = mock_session
    request_id = mock_lambda_context.aws_request_id

    # Create a mock aircraft subtype object
    aircraft_subtype_object = MagicMock()
    original_aircraft_subtype_object_int = MagicMock()
    
    # Simulate an exception when trying to commit
    mock_session.commit.side_effect = Exception("Database commit error")

    # Act
    result = update_aircraft_subtype(aircraft_subtype_object, original_aircraft_subtype_object_int, request_id)


    # Assert
    assert result is None  # Ensure that the function returns None in case of an exception
    mock_session.rollback.assert_called_once()  # Ensure that rollback was called
    mock_session.close.assert_called_once()  # Ensure that session is closed


@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.db_manager.Database.get_session')
@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.aircraft_subtypes_dao_int.get_existing_record')
@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.aircraft_subtypes_dao_int.handle_no_existing_records')
def test_update_aircraft_subtype_success_with_no_record(mock_handle_no_existing_records, mock_get_existing_record, mock_get_session, mock_session, mock_object, mock_lambda_context):
    """Test successful deletion of an aircraft subtype."""
    request_id = mock_lambda_context.aws_request_id

    mock_get_existing_record.return_value = []  # Simulate no existing records found  
    aircraft_subtype_object_int = MagicMock()
    original_aircraft_subtype_object_int = MagicMock()
    mock_get_session.return_value = mock_session

   # Call the function
    result = update_aircraft_subtype(aircraft_subtype_object_int, original_aircraft_subtype_object_int, request_id)

    # Assertions
    assert result == aircraft_subtype_object_int
    mock_handle_no_existing_records.assert_called_once_with(mock_session, aircraft_subtype_object_int, request_id)
    mock_session.commit.assert_called_once()


@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.db_manager.Database.get_session')
def test_update_existing_record(mock_get_session, mock_lambda_context):
    """Test updating an existing record in the database."""
    request_id = mock_lambda_context.aws_request_id
    # Create a mock session
    mock_session = MagicMock()
    mock_get_session.return_value = mock_session
    
    # Create mock records
    existing_record = MagicMock()
    new_record = MagicMock()
    
    # Set new record values
    new_record.AIRCRAFT_OWNER = 'New Owner'
    new_record.AIRCRAFT_SUBTYPE = 'New Subtype'
    new_record.AIRCRAFT_TYPE_IATA = 'NTA'
    new_record.AIRCRAFT_TYPE_ICAO = 'NTA'
    new_record.AIRCRAFT_SUBTYPE_ICAO = 'NST'
    new_record.FLEET_CODE_FICO_CONSOLIDATED = 'FICO'
    new_record.EFFECTIVE_FROM_DATETIME = '2024-01-01'
    new_record.EFFECTIVE_TO_DATETIME = '2025-01-01'

    # Mock the ensure_datetime function if necessary
    with patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.aircraft_subtypes_dao_int.ensure_datetime') as mock_ensure_datetime:
        mock_ensure_datetime.side_effect = lambda x: x  # Just return the input for testing
        
        # Call the function
        update_existing_record(mock_session, existing_record, new_record, request_id)

        # Assertions to check if the fields were updated
        assert existing_record.AIRCRAFT_OWNER == 'New Owner'
        assert existing_record.AIRCRAFT_SUBTYPE == 'New Subtype'
        assert existing_record.AIRCRAFT_TYPE_IATA == 'NTA'
        assert existing_record.AIRCRAFT_TYPE_ICAO == 'NTA'
        assert existing_record.AIRCRAFT_SUBTYPE_ICAO == 'NST'
        assert existing_record.FLEET_CODE_FICO_CONSOLIDATED == 'FICO'

        # Check effective dates
        assert existing_record.EFFECTIVE_FROM_DATETIME == '2024-01-01'
        assert existing_record.EFFECTIVE_TO_DATETIME == '2025-01-01'

        # Ensure merge was called on the session
        mock_session.merge.assert_called_once_with(existing_record)



@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.db_manager.Database.get_session')
@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.aircraft_subtypes_dao_int.get_existing_record')
@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.aircraft_subtypes_dao_int.check_effective_to_datetime')
def test_handle_existing_records(mock_check_effective, mock_get_existing_record, mock_get_session, mock_lambda_context):
    """Test handling existing records in the database."""

    request_id = mock_lambda_context.aws_request_id
    mock_session = MagicMock()
    mock_get_session.return_value = mock_session

    aircraft_subtype_object_int = MagicMock()
    existing_records = MagicMock()

    # Scenario 1: When matching records are found
    mock_get_existing_record.return_value = [MagicMock(), MagicMock()]  # Simulate matching records

    handle_existing_records(mock_session, aircraft_subtype_object_int, existing_records, request_id)

    # Assertions for Scenario 1
    mock_get_existing_record.assert_called_once_with(mock_session, aircraft_subtype_object_int, request_id)
    mock_check_effective.assert_called_once_with(mock_session, aircraft_subtype_object_int, mock_get_existing_record.return_value, request_id)

    # Reset mocks for the next scenario
    mock_get_existing_record.reset_mock()
    mock_check_effective.reset_mock()

    # Scenario 2: When no matching records are found
    mock_get_existing_record.return_value = []  # Simulate no matching records

    handle_existing_records(mock_session, aircraft_subtype_object_int, existing_records, request_id)

    # Assertions for Scenario 2
    mock_get_existing_record.assert_called_once_with(mock_session, aircraft_subtype_object_int, request_id)
    mock_check_effective.assert_called_once_with(mock_session, aircraft_subtype_object_int, existing_records, request_id)




class MockAircraftSubtypeObjectInt:
    AIRCRAFT_OWNER = "owner_test"
    AIRCRAFT_SUBTYPE = "subtype_test"

aircraft_subtype_object_int = MockAircraftSubtypeObjectInt()
request_id = "test_request_id"

@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_debug")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_error")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.starter.configs")
def test_get_existing_record_exception(mock_configs, mock_log_error, mock_log_debug):
    # Mock the session and force it to raise an exception
    mock_session = MagicMock()
    mock_session.query.side_effect = Exception("Database error")
    
    # Configure error message in mock configs
    mock_configs['TECHNICAL EXCEPTIONS'] = {'cr_ref_acst_rtu_500-0003': 'psycopg2 Error executing query'}

    # Call the function with the mock session
    result = get_existing_record(mock_session, aircraft_subtype_object_int, request_id)

    # Assertions to ensure the exception block was executed
    assert result is None
    mock_log_error.assert_called_once_with("psycopg2 Error executing query")
    mock_log_debug.assert_any_call("The Exception is : Database error")
    # mock_log_debug.assert_any_call("Comparing Primary Keys for Matching Records")


class MockAircraftSubtypeObjectInt:
    AIRCRAFT_OWNER = "owner_test"
    AIRCRAFT_SUBTYPE = "subtype_test"

aircraft_subtype_object_int = MockAircraftSubtypeObjectInt()
request_id = "test_request_id"

@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_info")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_error")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_debug")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.update_error_code")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.starter.configs")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.aircraft_subtypes_dao_int.get_existing_record", return_value=None)
def test_handle_no_existing_records_else_block(
    mock_get_existing_record,
    mock_configs,
    mock_update_error_code,
    mock_log_debug,
    mock_log_error,
    mock_log_info
):
    # Mock session
    mock_session = MagicMock()
    
    # Set up the business exception message
    mock_configs['BUSINESS_EXCEPTIONS'] = {'cr_ref_acst_rtu_400-0093': 'FLIGHT_CREW_LICENSE_FLEET,FLIGHT_CREW_BASE_FLEET and BA_QUALIFIED_FLEET columns to be updated manually'}

    # Call the function with the mock session and input data
    handle_no_existing_records(mock_session, aircraft_subtype_object_int, request_id)
    

    # Assertions
    mock_log_info.assert_called_once_with("No match found for ActionType='Update'.")
    mock_update_error_code.assert_called_once_with('cr_ref_acst_rtu_400-0093')
    mock_log_error.assert_called_once_with("FLIGHT_CREW_LICENSE_FLEET,FLIGHT_CREW_BASE_FLEET and BA_QUALIFIED_FLEET columns to be updated manually")
    mock_session.add.assert_called_once_with(aircraft_subtype_object_int)
    mock_log_debug.assert_called_once_with("Successfully created AircraftSubtype in Database ")
    mock_session.flush.assert_called_once()
    mock_session.commit.assert_called_once()


@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_debug")
def test_ensure_datetime_valid_string(mock_log_debug):
    # Test valid datetime string in UTC format
    date_time_str = "2023-01-01T12:00:00Z"
    expected_result = datetime(2023, 1, 1, 12, 0, 0)  # Expected naive datetime
    result = ensure_datetime(date_time_str)
    assert result == expected_result
    mock_log_debug.assert_not_called()  # No debug logs should be called for a valid string


@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_debug")
def test_ensure_datetime_invalid_string(mock_log_debug):
    # Test invalid datetime string format
    date_time_str = "2023-01-01 12:00:00"  # Incorrect format
    result = ensure_datetime(date_time_str)
    assert result is None
    mock_log_debug.assert_called_once_with("ValueError: time data '2023-01-01 12:00:00' does not match format '%Y-%m-%dT%H:%M:%SZ' - Problem Parsing date string: 2023-01-01 12:00:00")


@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_debug")
def test_ensure_datetime_naive_datetime_object(mock_log_debug):
    # Test with a naive datetime object
    date_time_obj = datetime(2023, 1, 1, 12, 0, 0)  # Naive datetime
    result = ensure_datetime(date_time_obj)
    assert result == date_time_obj  # Should return the same naive datetime object
    mock_log_debug.assert_not_called()  # No debug logs should be called for a valid naive datetime


@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_debug")
def test_ensure_datetime_aware_datetime_object(mock_log_debug):
    # Test with an aware datetime object
    date_time_obj = datetime(2023, 1, 1, 12, 0, 0, tzinfo=ZoneInfo("UTC"))
    expected_result = datetime(2023, 1, 1, 12, 0, 0)  # Expected naive datetime
    result = ensure_datetime(date_time_obj)
    assert result == expected_result
    mock_log_debug.assert_not_called()  # No debug logs should be called for a valid aware datetime


@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_debug")
def test_ensure_datetime_invalid_type(mock_log_debug):
    # Test with an invalid type (not string or datetime)
    invalid_input = 12345  # Integer, invalid type
    result = ensure_datetime(invalid_input)
    assert result is None
    mock_log_debug.assert_called_once_with("TypeError: Expected a string or datetime object, got <class 'int'>")

