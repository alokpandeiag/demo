import pytest
from unittest.mock import patch, MagicMock, Mock
from src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.starter import main  # Import the main function

xml_message_create = """<?xml version="1.0" encoding="UTF-8"?> 
<aircraftSubtype 	actionType="CREATE" 	timestamp="2017-08-09T01:10:00Z" 	schemaVersion="2.0" xmlns="http://iflight.ibsplc.com/" 	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://iflight.ibsplc.com/ AircraftSubtype.xsd "> 
    <aircraftSubtypeIdentifier> 
        <aircraftOwner>BA</aircraftOwner> 
        <aircraftSubtype>330</aircraftSubtype> 
        <validFromDateTime>2015-01-29T01:10:00Z</validFromDateTime> 
        <validToDateTime>2026-01-29T01:10:00Z</validToDateTime> 
    </aircraftSubtypeIdentifier> 
</aircraftSubtype>"""

xml_message_update = """<?xml version="1.0" encoding="UTF-8"?> 
<aircraftSubtype 	actionType="UPDATE" 	timestamp="2017-08-09T01:10:00Z" 	schemaVersion="2.0" xmlns="http://iflight.ibsplc.com/" 	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://iflight.ibsplc.com/ AircraftSubtype.xsd "> 
    <aircraftSubtypeIdentifier> 
        <aircraftOwner>BA</aircraftOwner> 
        <aircraftSubtype>330</aircraftSubtype> 
        <validFromDateTime>2015-01-29T01:10:00Z</validFromDateTime> 
        <validToDateTime>2026-01-29T01:10:00Z</validToDateTime> 
    </aircraftSubtypeIdentifier> 
</aircraftSubtype>"""

xml_message_delete = """<?xml version="1.0" encoding="UTF-8"?> 
<aircraftSubtype 	actionType="DELETE" 	timestamp="2017-08-09T01:10:00Z" 	schemaVersion="2.0" xmlns="http://iflight.ibsplc.com/" 	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://iflight.ibsplc.com/ AircraftSubtype.xsd "> 
    <aircraftSubtypeIdentifier> 
        <aircraftOwner>BA</aircraftOwner> 
        <aircraftSubtype>330</aircraftSubtype> 
        <validFromDateTime>2015-01-29T01:10:00Z</validFromDateTime> 
        <validToDateTime>2026-01-29T01:10:00Z</validToDateTime> 
    </aircraftSubtypeIdentifier> 
</aircraftSubtype>"""


@pytest.fixture
def mock_lambda_context():
    mock_context = Mock()
    mock_context.aws_request_id = 'mock_request_id'
    return mock_context


@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.parse_xml_message")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.initialize_aircraft_subtype_object_int")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.action_type_create")
def test_main_create_action_success(mock_action_type_create, mock_initialize, mock_parse_xml, mock_lambda_context):
    request_id = mock_lambda_context.aws_request_id
    # Mock the parse_xml_message to return a dictionary with actionType as CREATE
    mock_parse_xml.return_value = {
        'aircraftSubtype': {
            '@actionType': 'CREATE',
            'aircraftSubtypeIdentifier': {}
        }
    }
    # Mock initialization and action_type_create functions
    mock_initialize.return_value = "aircraft_object_mock"
    mock_action_type_create.return_value = "Success"

    # Call the main function
    result = main(xml_message_create, request_id)

    # Verify that the result is 'Success'
    assert result == 'Success'


@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.parse_xml_message")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.initialize_aircraft_subtype_object_int")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_error")
def test_main_create_action_initialization_failure(mock_logger, mock_initialize, mock_parse_xml, mock_lambda_context):
    request_id = mock_lambda_context.aws_request_id
    mock_parse_xml.return_value = {
        'aircraftSubtype': {
            '@actionType': 'CREATE',
            'aircraftSubtypeIdentifier': {}
        }
    }
    # Simulate initialization failure by returning None
    mock_initialize.return_value = None

    result = main(xml_message_create, request_id)

    # Verify the result is 'Failure' due to initialization failure
    assert result == 'Failure'
    mock_logger.log_error("Failed to initialize aircraft object for CREATE action.")



@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.parse_xml_message")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.initialize_aircraft_subtype_object_int")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.initialize_original_aircraft_subtype_object_int")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.action_type_update")
def test_main_update_action_success(mock_action_type_update, mock_initialize_original, mock_initialize, mock_parse_xml, mock_lambda_context):
    request_id = mock_lambda_context.aws_request_id
    mock_parse_xml.return_value = {
        'aircraftSubtype': {
            '@actionType': 'UPDATE',
            'aircraftSubtypeIdentifier': {'originalSubtypeIdentifier': {}}
        }
    }
    mock_initialize.return_value = "aircraft_object_mock"
    mock_initialize_original.return_value = "original_aircraft_object_mock"
    mock_action_type_update.return_value = "Success"

    result = main(xml_message_update, request_id)

    assert result == 'Success'

@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.parse_xml_message")
def test_main_unknown_action_type(mock_parse_xml, mock_lambda_context):
    request_id = mock_lambda_context.aws_request_id
    mock_parse_xml.return_value = {
        'aircraftSubtype': {
            '@actionType': 'UNKNOWN'
        }
    }

    result = main("<xml>...</xml>", request_id)

    # Verify the result is 'Failure' due to unknown action type
    assert result == 'Failure'


@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.parse_xml_message")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.delete_aircraft_subtype_object_int")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.action_type_delete")
def test_main_delete_action_success(mock_action_type_delete, mock_delete, mock_parse_xml, mock_lambda_context):
    request_id = mock_lambda_context.aws_request_id
    # Mock the parse_xml_message to return a dictionary with actionType as DELETE
    mock_parse_xml.return_value = {
        'aircraftSubtype': {
            '@actionType': 'DELETE',
            'aircraftSubtypeIdentifier': {}
        }
    }
    # Mock initialization and action_type_create functions
    mock_delete.return_value = "aircraft_object_mock"
    mock_action_type_delete.return_value = "Success"

    # Call the main function
    result = main(xml_message_delete, request_id)

    # Verify that the result is 'Success'
    assert result == 'Success'

@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.parse_xml_message")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.delete_aircraft_subtype_object_int")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_error")
def test_main_delete_action_initialization_failure(mock_logger, mock_delete, mock_parse_xml, mock_lambda_context):
    request_id = mock_lambda_context.aws_request_id
    mock_parse_xml.return_value = {
        'aircraftSubtype': {
            '@actionType': 'DELETE',
            'aircraftSubtypeIdentifier': {}
        }
    }
    # Simulate initialization failure by returning None
    mock_delete.return_value = None

    result = main(xml_message_create, request_id)

    # Verify the result is 'Failure' due to initialization failure
    assert result == 'Failure'
    mock_logger.log_error("Failed to initialize aircraft object for DELETE action.")


def test_main_failure_case():
    xml_message = "<InvalidXML></InvalidXML>"  # or any input that should return None
    request_id = "test_request_id"

    # Mock asi.parse_xml_message to return None to simulate failure
    with patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.parse_xml_message', return_value=None):
        result = main(xml_message, request_id)

    assert result == 'Failure'


# Define your test
def test_main_exception_handling():
    # Create a mock configuration
    mock_configs = MagicMock()
    
    # Mock the TECHNICAL EXCEPTIONS section
    mock_configs.__getitem__.return_value = {
        'cr_ref_acst_rtu_500-0030': 'Error Processing File',
    }
    
    with patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.starter._logger") as mock_logger:
        with patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.parse_xml_message", side_effect=Exception("Test Exception")):
            with patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.starter.configs", mock_configs):
                # Call the main function
                result = main("<test>message</test>", "test-request-id")
                
                # Assert that the correct error message is logged
                mock_logger.log_error.assert_any_call('Error Processing File')  # This is the message for cr_ref_acst_rtu_500-0030
                mock_logger.log_error.assert_any_call('The Exception is Test Exception')  # Log the actual exception as well





