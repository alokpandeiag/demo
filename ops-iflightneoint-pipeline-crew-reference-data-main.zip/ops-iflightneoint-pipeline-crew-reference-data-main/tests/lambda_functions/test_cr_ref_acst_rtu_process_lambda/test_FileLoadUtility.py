
import pytest
from unittest import mock
import builtins
import yaml
from src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.FileLoadUtility import load_log_config_file, load_err_file

#Negative test cases only to cover the exception. Other paths are covered in other test cases
def test_load_config_file():
    prop = load_log_config_file()
    assert prop is not None

def test_load_log_config_file_ioerror():
    # Simulate an IOError when opening the file
    with mock.patch.object(builtins, 'open', side_effect=IOError("File not found")):
        result = load_log_config_file()
        assert result is None


def test_load_log_config_file_exception():
    # Simulate an IOError when opening the file
    with mock.patch.object(builtins, 'open', side_effect=Exception("File Path not found")):
        result = load_log_config_file()
        assert result is None


def test_load_err_file_ioerror():
    # Simulate an IOError when opening the file
    with mock.patch.object(builtins, 'open', side_effect=IOError("File not found")):
        result = load_err_file()
        assert result is None


def test_load_err_file_exception():
    # Simulate an IOError when opening the file
    with mock.patch.object(builtins, 'open', side_effect=Exception("File Path not found")):
        result = load_err_file()
        assert result is None
