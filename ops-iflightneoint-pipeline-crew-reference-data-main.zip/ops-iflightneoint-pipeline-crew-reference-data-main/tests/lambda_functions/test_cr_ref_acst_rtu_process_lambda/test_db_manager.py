import pytest
from unittest import  mock
from unittest.mock import patch
import json
import os
from unittest.mock import Mock
from src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.db_manager import Database


@pytest.fixture
def mock_lambda_context():
    mock_context = Mock()
    mock_context.aws_request_id = 'mock_request_id'
    return mock_context


# Mocking AWS Secrets Manager and SQLAlchemy session
@pytest.fixture
def mock_boto3_client():
    with mock.patch("boto3.client") as mock_client:
        yield mock_client
 
@pytest.fixture
def mock_logger():
    with mock.patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory") as mock_logger:
        yield mock_logger
 
@pytest.fixture
def mock_create_engine():
    with mock.patch("sqlalchemy.create_engine") as mock_engine:
        yield mock_engine
 
# Mocking environment variables
@pytest.fixture
def set_env_variables():
    os.environ["REGION"] = "us-west-2"
    os.environ["RDS_SECRET_NAME"] = "dummy_secret_name"
 
# Mock database credentials
@pytest.fixture
def mock_db_credentials():
    db_credentials = {
        "username": "test_user",
        "password": os.environ.get('password','test'),
        "host": "localhost",
        "port": "5432",
        "dbname": "test_db"
    }
    return db_credentials
 
# Test the get_db_credentials function
def test_get_db_credentials_success(mock_boto3_client, mock_lambda_context, mock_db_credentials):
    # Mocking the response from AWS Secrets Manager
    mock_client_instance = mock_boto3_client.return_value
    mock_client_instance.get_secret_value.return_value = {
        "SecretString": json.dumps(mock_db_credentials)
    }
    request_id = mock_lambda_context.aws_request_id
    result = Database.get_db_credentials(os.environ.get('RDS_SECRET_NAME'), request_id)
    assert result == mock_db_credentials, f"Expected {mock_db_credentials}, but got {result}"
 
def test_get_db_credentials_exception(mock_boto3_client, mock_lambda_context):
    request_id = mock_lambda_context.aws_request_id
    # Set up the mock for the boto3 client
    mock_client_instance = mock_boto3_client.return_value
    mock_client_instance.get_secret_value.side_effect  = Exception("Cannot find Secret String")    

    # Set the environment variable for the test
    os.environ['REGION'] = 'us-east-1'
    secret_name = 'test_secret'
    
    # Call the function and assert that it raises an exception
    with pytest.raises(Exception) as context:
        Database.get_db_credentials(secret_name, request_id)
        print({context.value})
    
    # Optional: Check the exception message
    assert str(context.value) == "Cannot find Secret String"

# Test get_engine function
def test_get_engine_success(mock_boto3_client, mock_db_credentials, mock_lambda_context):
    # Mock AWS Secrets Manager response
    mock_client_instance = mock_boto3_client.return_value
    mock_client_instance.get_secret_value.return_value = {
        "SecretString": json.dumps(mock_db_credentials)    }
 
    # Mock SQLAlchemy engine creation ###Already mocked
   # mock_create_engine.return_value = mock.Mock()
    request_id = mock_lambda_context.aws_request_id
    engine = Database.get_engine(request_id)
    assert engine is not None, "Expected engine to be created but got None"

 
# Test get_session function
@patch('src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.dao.db_manager.Database.get_engine')
def test_get_session_success(mock_method, mock_boto3_client, mock_create_engine, mock_lambda_context, mock_db_credentials):
    # Mock AWS Secrets Manager response
    mock_client_instance = mock_boto3_client.return_value
    mock_client_instance.get_secret_value.return_value = {
        "SecretString": json.dumps(mock_db_credentials)
    }
 
    # Mock SQLAlchemy engine creation and sessionmaker
    mock_engine_instance = mock_create_engine.return_value
    mock_method.return_value = mock_engine_instance
    #mock_session = sessionmaker(bind=mock_engine_instance)
    request_id = mock_lambda_context.aws_request_id
    session = Database.get_session(request_id)
    assert session is not None, "Expected a session object but got None"
 
# Test the close_connection function
def test_close_connection(mock_logger):
    # Mock a database connection
    Database._connection = mock.Mock()
    Database.close_connection()
    
    # Check if close() method was called
    Database._connection.close.assert_called_once()