from src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.XMLtojsonobject import json_object_from_xml
import pytest
import os 
from unittest.mock import Mock

@pytest.fixture
def current_dir():
    return os.getcwd() 

@pytest.fixture
def mock_lambda_context():
    mock_context = Mock()
    mock_context.aws_request_id = 'mock_request_id'
    return mock_context

@pytest.fixture
def file_path_xml(current_dir):
    return current_dir + '/tests/lambda_functions/test_cr_ref_acst_rtu_process_lambda/Delete.xml'
    
def test_json_object_from_xml(file_path_xml, mock_lambda_context):
    with open(file_path_xml, 'r') as file:
        xml_content = file.read()
        request_id = mock_lambda_context.aws_request_id
        json_obj = json_object_from_xml(xml_content,  request_id)

    assert "DELETE" == json_obj['aircraftSubtype']['@actionType']

@pytest.fixture
def invalid_path_xml(current_dir):
    return current_dir +'/invalid/tests/create_invalid.xml'


def test_json_object_from_xml_invalid_path(invalid_path_xml, mock_lambda_context):
    request_id = mock_lambda_context.aws_request_id
    try:
        with open(invalid_path_xml, 'r') as file:
            xml_content = file.read()
            isvalid = json_object_from_xml(xml_content, request_id)
        assert not isvalid
    except FileNotFoundError:
        assert True  # Expecting a file not found error



@pytest.fixture
def invalid_xml(current_dir):
    return current_dir + '/tests/lambda_functions/test_cr_ref_acst_rtu_process_lambda/create.xml'

def test_json_object_from_xml_invalid_xml(invalid_xml, mock_lambda_context):
    request_id = mock_lambda_context.aws_request_id
    with open(invalid_xml, 'r') as file:
        xml_content = file.read()
        json_obj = json_object_from_xml(xml_content, request_id)
    assert not json_obj  # Expecting None for invalid XML content



# @pytest.fixture
# def ecs_file_type_invalid_xml(current_dir):
#     return current_dir + '/resources/error.properties'
# #Negative test case to test the Exceptions file type error
# def test_json_object_from_xml_invalid_file(ecs_file_type_invalid_xml):
#     json_obj = None   
#     json_obj = json_object_from_xml(ecs_file_type_invalid_xml)
#     assert json_obj is None