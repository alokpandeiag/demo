import pytest
from unittest.mock import Mock, patch, MagicMock
from src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int import parse_xml_message, initialize_aircraft_subtype_object_int, initialize_original_aircraft_subtype_object_int, delete_aircraft_subtype_object_int, action_type_update, action_type_create, action_type_delete

@pytest.fixture
def sample_json_object():
    # Sample JSON object for testing
    return {
        'aircraftSubtype': {
            'aircraftSubtypeIdentifier': {
                'aircraftOwner': 'Owner1',
                'aircraftSubtype': 'Subtype1',
                'validFromDateTime': '2024-01-01T00:00:00Z',
                'validToDateTime': '2024-12-31T23:59:59Z',
                'originalSubtypeIdentifier': {
                    'originalAircraftOwner': 'Owner1',
                    'originalAircraftSubtype': 'Subtype1',
                    'originalValidFromDateTime': '2023-01-01T00:00:00Z'
                }
            },
            'typeInformation': {
                'aircraftTypeIata': 'IATA123',
                'aircraftTypeIcao': 'ICAO123',
                'aircraftSubtypeICAO': 'ICAO456',
                'aircraftSubtypeLocal': 'LocalSubtype'
            }
        }
    }

@pytest.fixture
def mock_request_id():
    return 'request-12345'

@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.create_aircraft_subtype")
def test_action_type_create(mock_create_aircraft_subtype, sample_json_object, mock_request_id):
    # Mock the create function to simulate a successful insert
    mock_create_aircraft_subtype.return_value = True

    # Initialize the object for creation
    aircraft_subtype_object = initialize_aircraft_subtype_object_int(sample_json_object, mock_request_id)
    result = action_type_create(aircraft_subtype_object, mock_request_id)
    
    assert result == "Success"
    mock_create_aircraft_subtype.assert_called_once_with(aircraft_subtype_object, mock_request_id)

@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.update_aircraft_subtype")
def test_action_type_update(mock_update_aircraft_subtype, sample_json_object, mock_request_id):
    # Mock the update function to simulate a successful update
    mock_update_aircraft_subtype.return_value = True

    # Initialize the objects for update
    aircraft_subtype_object = initialize_aircraft_subtype_object_int(sample_json_object, mock_request_id)
    original_aircraft_subtype_object = initialize_original_aircraft_subtype_object_int(sample_json_object, mock_request_id)
    
    result = action_type_update(aircraft_subtype_object, original_aircraft_subtype_object, mock_request_id)
    
    assert result == "Success"
    mock_update_aircraft_subtype.assert_called_once_with(aircraft_subtype_object, original_aircraft_subtype_object, mock_request_id)

@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.delete_aircraft_subtype")
def test_action_type_delete(mock_delete_aircraft_subtype, sample_json_object, mock_request_id):
    # Mock the delete function to simulate a successful delete
    mock_delete_aircraft_subtype.return_value = True

    # Initialize the object for deletion
    delete_aircraft_subtype_object = delete_aircraft_subtype_object_int(sample_json_object, mock_request_id)
    result = action_type_delete(delete_aircraft_subtype_object, mock_request_id)
    
    assert result == "Success"
    mock_delete_aircraft_subtype.assert_called_once_with(delete_aircraft_subtype_object, mock_request_id)

@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_debug")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.json_object_from_xml")
def test_parse_xml_message_success(mock_json_object_from_xml, mock_logger, sample_json_object, mock_request_id):
    # Mock XML to JSON conversion
    mock_json_object_from_xml.return_value = sample_json_object

    xml_file = "<xml>sample</xml>"
    result = parse_xml_message(xml_file, mock_request_id)

    assert result == sample_json_object
    mock_logger.log_debug("XML message converted to JSON OBJECTS successfully.")

@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.update_error_code")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_error")
def test_initialize_aircraft_subtype_object_int_missing_key_create(mock_log_error, mock_update_error_code, sample_json_object, mock_request_id):
    # Remove a key to simulate KeyError
    del sample_json_object['aircraftSubtype']['typeInformation']['aircraftTypeIata']

    result = initialize_aircraft_subtype_object_int(sample_json_object, mock_request_id)

    assert result is None
    mock_update_error_code.assert_called_once_with('cr_ref_acst_rtu_300-0037')
    mock_log_error.assert_any_call("The Element Missing is : 'aircraftTypeIata'")

@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_info")
def test_initialize_original_aircraft_subtype_object_int_success(mock_log_info, sample_json_object, mock_request_id):
    result = initialize_original_aircraft_subtype_object_int(sample_json_object, mock_request_id)
    
    assert result is not None
    mock_log_info.assert_called_once_with(f"Initialized Update AircraftSubtype object: {result}")


@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.update_error_code")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_error")
def test_initialize_aircraft_subtype_object_int_missing_key_update(mock_log_error, mock_update_error_code, sample_json_object, mock_request_id):
    # Remove a key to simulate KeyError
    del sample_json_object['aircraftSubtype']['typeInformation']['aircraftTypeIata']

    result = initialize_original_aircraft_subtype_object_int(sample_json_object, mock_request_id)

    assert result is None
    mock_update_error_code.assert_called_once_with('cr_ref_acst_rtu_300-0037')
    mock_log_error.assert_any_call("The Element Missing is : 'aircraftTypeIata'")


@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.update_error_code")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_error")
def test_initialize_aircraft_subtype_object_int_missing_key_delete(mock_log_error, mock_update_error_code, sample_json_object, mock_request_id):
    # Remove a key to simulate KeyError
    del sample_json_object['aircraftSubtype']['aircraftSubtypeIdentifier']['aircraftOwner']

    result = delete_aircraft_subtype_object_int(sample_json_object, mock_request_id)

    assert result is None
    mock_update_error_code.assert_called_once_with('cr_ref_acst_rtu_300-0037')
    mock_log_error.assert_any_call("The Element Missing is : 'aircraftOwner'")


@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.update_error_code")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_error")
def test_delete_aircraft_subtype_object_int_general_exception(mock_log_error, mock_update_error_code):
    # Mock json_object to raise an exception when accessed
    json_object = MagicMock()
    json_object.__getitem__.side_effect = Exception("Unexpected error")
    request_id = "request-12345"
    
    # Call function
    result = delete_aircraft_subtype_object_int(json_object, request_id)

    # Verify result is None
    assert result is None

    # Verify logging calls for general Exception handling
    mock_update_error_code.assert_called_once_with('cr_ref_acst_rtu_400-0085')
    mock_log_error.assert_any_call("The Exception is : Unexpected error")


@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.update_error_code")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_error")
def test_update_aircraft_subtype_object_int_general_exception(mock_log_error, mock_update_error_code):
    # Mock json_object to raise an exception when accessed
    json_object = MagicMock()
    json_object.__getitem__.side_effect = Exception("Unexpected error")
    request_id = "request-12345"
    
    # Call function
    result = initialize_original_aircraft_subtype_object_int(json_object, request_id)

    # Verify result is None
    assert result is None

    # Verify logging calls for general Exception handling
    mock_update_error_code.assert_called_once_with('cr_ref_acst_rtu_400-0084')
    mock_log_error.assert_any_call("The Exception is : Unexpected error")



@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.update_error_code")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_error")
def test_create_aircraft_subtype_object_int_general_exception(mock_log_error, mock_update_error_code):
    # Mock json_object to raise an exception when accessed
    json_object = MagicMock()
    json_object.__getitem__.side_effect = Exception("Unexpected error")
    request_id = "request-12345"
    
    # Call function
    result = initialize_aircraft_subtype_object_int(json_object, request_id)

    # Verify result is None
    assert result is None

    # Verify logging calls for general Exception handling
    mock_update_error_code.assert_called_once_with('cr_ref_acst_rtu_400-0083')
    mock_log_error.assert_any_call("The Exception is : Unexpected error")



@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.update_error_code")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_error")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.create_aircraft_subtype")
def test_action_type_create_exception(mock_create_aircraft_subtype, mock_log_error, mock_update_error_code):
    # Arrange: Configure mocks to simulate exception
    mock_create_aircraft_subtype.side_effect = Exception("Unexpected error")
    aircraft_subtype_object_int = MagicMock()  # Mocked input object
    request_id = "request-12345"

    # Act: Call the function
    result = action_type_create(aircraft_subtype_object_int, request_id)

    # Assert: Check that result is "Failure" and logging was called correctly
    assert result == "Failure"
    mock_update_error_code.assert_called_once_with('cr_ref_acst_rtu_400-0086')
    mock_log_error.assert_any_call("The Exception is : Unexpected error")


@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.update_error_code")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_error")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.update_aircraft_subtype")
def test_action_type_update_exception(mock_create_aircraft_subtype, mock_log_error, mock_update_error_code):
    # Arrange: Configure mocks to simulate exception
    mock_create_aircraft_subtype.side_effect = Exception("Unexpected error")
    aircraft_subtype_object_int = MagicMock()  # Mocked input object
    original_aircraft_subtype_object_int = MagicMock()
    request_id = "request-12345"

    # Act: Call the function
    result = action_type_update(aircraft_subtype_object_int, original_aircraft_subtype_object_int, request_id)

    # Assert: Check that result is "Failure" and logging was called correctly
    assert result == "Failure"
    mock_update_error_code.assert_called_once_with('cr_ref_acst_rtu_400-0087')
    mock_log_error.assert_any_call("The Exception is : Unexpected error")

@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.update_error_code")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.util.LoggerFactory.log_error")
@patch("src.lambda_functions.cr_ref_acst_rtu_process_lambda.main.service.aircraft_subtype_int.delete_aircraft_subtype")
def test_action_type_delete_exception(mock_create_aircraft_subtype, mock_log_error, mock_update_error_code):
    # Arrange: Configure mocks to simulate exception
    mock_create_aircraft_subtype.side_effect = Exception("Unexpected error")
    aircraft_subtype_object_int = MagicMock()  # Mocked input object
    request_id = "request-12345"

    # Act: Call the function
    result = action_type_delete(aircraft_subtype_object_int, request_id)

    # Assert: Check that result is "Failure" and logging was called correctly
    assert result == "Failure"
    mock_update_error_code.assert_called_once_with('cr_ref_acst_rtu_400-0088')
    mock_log_error.assert_any_call("The Exception is : Unexpected error")


